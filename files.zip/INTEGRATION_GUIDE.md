# Zintoo Agentic Optimizer - Integration Guide

## What's New

You now have **three files** that replace the placeholder admin UI logic with real LangGraph agent reasoning:

### 1. **agent_optimizer.py** (CORE LOGIC)
- **What it does**: Multi-step LangGraph workflow for warehouse inventory optimization
- **Key components**:
  - `node_initialize`: Sets up the agent with pincode & product list
  - `node_analyze_next_product`: Analyzes demand trends + current inventory
  - `node_detect_risks`: Identifies stockout risks (critical/high/medium/low)
  - `node_plan_reallocations`: Creates reallocation orders for at-risk products
  - `node_summarize`: Generates final report
- **Entry point**: `run_optimization(pincode, demand_csv, inventory_csv)` → returns detailed results

### 2. **app_updated.py** (STREAMLIT INTEGRATION)
- **What changed**:
  - Replaced the fake "Run Agentic Optimization" button with real agent integration
  - New "Agentic Inventory" tab now calls `run_optimization()` and displays:
    - ✅ Live agent reasoning in status container
    - ⚠️  Alerts broken down by risk level (critical/high/medium)
    - 📦 Reallocation orders with full details
    - 📥 CSV export for orders
- **Usage**: Replace your current `app.py` with this file

### 3. **test_agent.py** (VERIFICATION SCRIPT)
- **What it does**: Standalone test to verify agent works before Streamlit integration
- **Usage**: `python test_agent.py`
- **Output**: Shows alerts & reallocation orders for a single pincode

---

## Installation Steps

### Step 1: Install LangGraph
```bash
pip install langgraph langchain
```

### Step 2: Place Files in Your Project
```
D:\FASHION\
├── agent_optimizer.py          ← NEW
├── app.py                       ← REPLACE with app_updated.py
├── main.py                      ← Keep as-is
├── make_forecast.py             ← Keep as-is
├── make_inventory.py            ← Keep as-is
├── reindex.py                   ← Keep as-is
└── data/
    ├── demand_forecast.csv      ← Keep as-is
    ├── warehouse_inventory.csv  ← Keep as-is
    ├── products.csv             ← Keep as-is
    └── fashion.index            ← Keep as-is
```

### Step 3: Test the Agent
```bash
cd D:\FASHION
python test_agent.py
```

**Expected output:**
```
======================================================================
  Testing Pincode: 560001
======================================================================

✅ Status: Optimization Complete | Products Analyzed: 10 | Alerts: 5 | Reallocation Orders: 3

Summary:
  📊 Products Analyzed: 10
  ⚠️  Alerts Raised: 5
  📦 Reallocation Orders: 3

⚠️  TOP ALERTS (5):
1. Product Name
   Risk Level: CRITICAL
   Current Stock: 2 units
   Days of Stock: 0.42 days
...
```

### Step 4: Run Streamlit with New App
```bash
streamlit run app_updated.py
```

Go to: **🤖 Agentic Inventory** tab → Select pincode → Click **🚀 Run Agent**

---

## How the Agent Works (High-Level)

```
[Pincode] 
    ↓
[Initialize: Get all products in pincode]
    ↓
[Analyze Each Product: 
  - Get 30-day historical demand
  - Get 7-day forecast demand
  - Get current stock levels across 3 warehouses]
    ↓
[Detect Risk:
  - If days_of_stock < 2 → CRITICAL
  - If days_of_stock < 5 → HIGH
  - If days_of_stock < 10 → MEDIUM]
    ↓
[Plan Reallocations:
  - If risk detected, find source warehouse with highest stock
  - Create order to move stock to pincode's primary warehouse
  - Quantity = 2.5x forecasted daily demand (safety stock)]
    ↓
[Summarize & Return:
  - Final report with alerts & orders
  - Ready for CSV export or downstream systems]
```

---

## Key Features

### Risk Detection Logic
- **Days of Stock** = `current_stock / forecasted_daily_demand`
- **Critical**: < 2 days OR stock = 0
- **High**: < 5 days
- **Medium**: < 10 days
- **Low**: ≥ 10 days

### Reallocation Heuristic
```python
source_warehouse = warehouse_with_highest_stock(product_id)
destination_warehouse = closest_warehouse_to_pincode()
quantity = 2.5 * forecasted_daily_demand  # Safety multiplier
```

### Data Flow
- **Demand data**: Product ID + Pincode + Historical (30d) + Forecast (7d)
- **Inventory data**: Product ID + Warehouse + Current stock
- **Output**: Reallocation orders with priority level + reason + timestamp

---

## Customization Options

### Adjust Risk Thresholds
In `agent_optimizer.py`, function `detect_stockout_risk()`:
```python
def detect_stockout_risk(demand_analysis: dict, inventory_status: dict, safety_margin: int = 2):
    # Change safety_margin (default=2 days) to adjust sensitivity
    if stock_days_remaining < safety_margin:
        risk_level = 'critical'
```

### Adjust Safety Stock Multiplier
In `agent_optimizer.py`, function `plan_reallocation()`:
```python
quantity = int(forecasted_demand * 2.5)  # Change 2.5 to any factor
```

### Add More Warehouses
In `agent_optimizer.py`, function `check_inventory_levels()`:
```python
pincode_to_warehouse = {
    560001: ['W1 (North BLR)', 'W2 (South BLR)', 'W3 (Central Hub)'],
    # Add more mappings
}
```

---

## Troubleshooting

### Error: "No module named 'langgraph'"
```bash
pip install langgraph langchain
```

### Error: "File not found: D:\FASHION\..."
- Update paths in `agent_optimizer.py` to match your setup
- Use `r"path\to\file"` for Windows paths

### Agent returns 0 alerts
- Check that `demand_forecast.csv` has future dates (is_forecast=True)
- Verify `warehouse_inventory.csv` has correct stock levels
- Increase forecast demand in `make_forecast.py`

### Streamlit app won't load
- Make sure `app_updated.py` is in same directory as `main.py`
- Verify import path: `sys.path.insert(0, r"D:\FASHION")`

---

## For Hackathon Judging

### What to Highlight:
1. ✅ **Multi-modal retrieval**: CLIP for text + image search
2. ✅ **AI-powered forecasting**: Demand prediction per pincode
3. ✅ **Agentic reasoning**: LangGraph for autonomous warehouse optimization
4. ✅ **Real-world impact**: 60-min hyper-local delivery + cost savings

### Demo Flow:
1. Customer View: Search "White linen shirt" → Get 9 matches with CLIP embeddings
2. Admin View: Select pincode → Run agent → See alerts & reallocation orders
3. Show order CSV export
4. Mention risk detection logic + safety stock calculation

---

## Next Steps (Optional)

- [ ] Add actual FastAPI integration to receive & execute reallocation orders
- [ ] Implement real warehouse capacity constraints
- [ ] Add delivery time estimates between warehouses
- [ ] Hook up to notification system (SMS/push for fulfillment teams)
- [ ] Track reallocation order success rates over time
