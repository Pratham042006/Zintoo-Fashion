import pandas as pd
import numpy as np

# --- ENHANCED WAREHOUSE INVENTORY ---

# Load your 7,000 synced products
df_products = pd.read_csv(r"D:\FASHION\data\products.csv")

# Warehouse metadata
WAREHOUSES = {
    'W1': {'name': 'W1 (North BLR)', 'pincode': 560001, 'location': 'Whitefield'},
    'W2': {'name': 'W2 (South BLR)', 'pincode': 560037, 'location': 'BTM Layout'},
    'W3': {'name': 'W3 (Central Hub)', 'pincode': 560064, 'location': 'Koramangala'},
}

inventory_data = []

print("Generating enhanced warehouse inventory with reorder thresholds...")

for idx, (_, product) in enumerate(df_products.iterrows()):
    if idx % 1000 == 0:
        print(f"Processing product {idx}/7000...")
    
    product_id = int(product['id'])
    product_name = product['productDisplayName']
    sku = f"SKU-{product_id}"
    
    # Product-specific base demand (some items sell more than others)
    base_daily_demand = np.random.randint(5, 50)
    
    # Reorder threshold = 3× peak daily demand (safety stock for 3 days)
    peak_daily_demand = base_daily_demand * 1.5  # ~peak over historical period
    reorder_threshold = int(peak_daily_demand * 3)
    
    for warehouse_id, warehouse_info in WAREHOUSES.items():
        # Stock distribution varies by warehouse
        # Central hub (W3) has more stock, others are regional
        if warehouse_id == 'W3':
            stock_range = (int(reorder_threshold * 1.5), int(reorder_threshold * 3))
        else:
            stock_range = (int(reorder_threshold * 0.5), int(reorder_threshold * 1.5))
        
        current_stock = np.random.randint(*stock_range)
        
        inventory_data.append({
            'product_id': product_id,
            'sku': sku,
            'product_name': product_name,
            'warehouse_id': warehouse_id,
            'warehouse_name': warehouse_info['name'],
            'warehouse_location': warehouse_info['location'],
            'pincode': warehouse_info['pincode'],
            'current_stock': current_stock,
            'reorder_threshold': reorder_threshold,
            'max_capacity': int(reorder_threshold * 5),  # Max storage capacity
            'stock_level': 'healthy' if current_stock > reorder_threshold else 'low'
        })

# Create DataFrame
df_inventory = pd.DataFrame(inventory_data)

# Save enhanced inventory
output_path = r"D:\FASHION\data\warehouse_inventory_enhanced.csv"
df_inventory.to_csv(output_path, index=False)

print(f"\n✅ Enhanced inventory generated!")
print(f"Total inventory entries: {len(df_inventory)}")
print(f"Products: {df_inventory['product_id'].nunique()}")
print(f"Warehouses: {df_inventory['warehouse_id'].nunique()}")
print(f"Saved to: {output_path}")

# --- SUMMARY STATISTICS ---
print("\n" + "="*80)
print("WAREHOUSE INVENTORY SUMMARY")
print("="*80)

for warehouse_id in ['W1', 'W2', 'W3']:
    wh_data = df_inventory[df_inventory['warehouse_id'] == warehouse_id]
    wh_name = wh_data['warehouse_name'].iloc[0]
    
    total_stock = wh_data['current_stock'].sum()
    avg_stock = wh_data['current_stock'].mean()
    max_capacity = wh_data['max_capacity'].sum()
    
    healthy = len(wh_data[wh_data['stock_level'] == 'healthy'])
    low = len(wh_data[wh_data['stock_level'] == 'low'])
    
    utilization = (total_stock / max_capacity) * 100 if max_capacity > 0 else 0
    
    print(f"\n📦 {wh_name}")
    print(f"   Total Stock: {total_stock:,} units")
    print(f"   Avg Stock per SKU: {avg_stock:.1f} units")
    print(f"   Capacity: {total_stock:,} / {max_capacity:,} ({utilization:.1f}%)")
    print(f"   Stock Status: {healthy} healthy, {low} low")
    print(f"   Location: {wh_data['warehouse_location'].iloc[0]}")

# --- REORDER THRESHOLD DISTRIBUTION ---
print("\n" + "="*80)
print("REORDER THRESHOLD DISTRIBUTION")
print("="*80)

print(f"\nReorder Threshold Stats:")
print(f"  Min: {df_inventory['reorder_threshold'].min()} units")
print(f"  Max: {df_inventory['reorder_threshold'].max()} units")
print(f"  Mean: {df_inventory['reorder_threshold'].mean():.1f} units")
print(f"  Median: {df_inventory['reorder_threshold'].median():.1f} units")

low_stock_count = len(df_inventory[df_inventory['current_stock'] < df_inventory['reorder_threshold']])
print(f"\nItems below reorder threshold: {low_stock_count} ({low_stock_count/len(df_inventory)*100:.1f}%)")

# --- CRITICAL LOW STOCK ITEMS ---
print("\n" + "="*80)
print("⚠️  CRITICAL LOW STOCK ITEMS (Below 50% of Reorder Threshold)")
print("="*80)

critical = df_inventory[df_inventory['current_stock'] < df_inventory['reorder_threshold'] * 0.5]
print(f"\nTotal critical items: {len(critical)}")

if len(critical) > 0:
    print("\nSample critical items:")
    sample = critical.nsmallest(10, 'current_stock')[['sku', 'product_name', 'warehouse_name', 'current_stock', 'reorder_threshold']]
    for idx, row in sample.iterrows():
        print(f"  {row['sku']} - {row['product_name'][:30]}")
        print(f"    Warehouse: {row['warehouse_name']} | Current: {row['current_stock']} | Threshold: {row['reorder_threshold']}")

# --- SKU AVAILABILITY ACROSS WAREHOUSES ---
print("\n" + "="*80)
print("SKU AVAILABILITY ACROSS WAREHOUSES")
print("="*80)

sku_availability = df_inventory.groupby('sku').agg({
    'current_stock': ['sum', 'mean', 'min', 'max'],
    'warehouse_id': 'count'
}).round(1)

sku_availability.columns = ['Total Stock', 'Avg per WH', 'Min Stock', 'Max Stock', 'Warehouses']

print(f"\nAvailability Stats:")
print(f"  SKUs with 0 stock in at least one warehouse: {len(df_inventory[df_inventory['current_stock'] == 0].groupby('sku'))}")
print(f"  SKUs in all 3 warehouses: {len(df_inventory[df_inventory['current_stock'] > 0].groupby('sku').filter(lambda x: len(x) == 3))}")

# --- SAMPLE DATA ---
print("\n" + "="*80)
print("SAMPLE INVENTORY DATA")
print("="*80)

print(df_inventory[['sku', 'product_name', 'warehouse_name', 'current_stock', 'reorder_threshold', 'stock_level']].head(20))

print("\n✅ Enhanced inventory generation complete!")
