import requests
import json
from datetime import datetime, timedelta
import pandas as pd

# --- OPEN-METEO WEATHER API INTEGRATION ---

class WeatherAPI:
    """Fetch real-time weather data from Open-Meteo (free, no auth required)"""
    
    BASE_URL = "https://api.open-meteo.com/v1/forecast"
    
    # Bangalore coordinates by pincode (approximate)
    BANGALORE_ZONES = {
        560001: {"lat": 12.9716, "lon": 77.5946, "name": "Bangalore CBD (560001)"},
        560037: {"lat": 13.0827, "lon": 77.6054, "name": "Bangalore South (560037)"},
        560064: {"lat": 12.9698, "lon": 77.5832, "name": "Bangalore East (560064)"},
    }
    
    @staticmethod
    def get_current_weather(pincode: int) -> dict:
        """Get current weather for a pincode"""
        if pincode not in WeatherAPI.BANGALORE_ZONES:
            return None
        
        zone = WeatherAPI.BANGALORE_ZONES[pincode]
        
        try:
            response = requests.get(
                WeatherAPI.BASE_URL,
                params={
                    "latitude": zone["lat"],
                    "longitude": zone["lon"],
                    "current": "temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m",
                    "temperature_unit": "celsius",
                    "timezone": "Asia/Kolkata"
                }
            )
            
            if response.status_code == 200:
                data = response.json()
                current = data['current']
                
                return {
                    'pincode': pincode,
                    'zone': zone['name'],
                    'timestamp': current['time'],
                    'temperature': current['temperature_2m'],
                    'humidity': current['relative_humidity_2m'],
                    'wind_speed': current['wind_speed_10m'],
                    'weather_code': current['weather_code'],
                    'weather_description': WeatherAPI.weather_code_to_description(current['weather_code']),
                    'demand_multiplier': WeatherAPI.weather_to_demand_multiplier(current['weather_code'], current['temperature_2m'])
                }
        except Exception as e:
            print(f"⚠️ Weather API error: {e}")
            return None
    
    @staticmethod
    def get_forecast_weather(pincode: int, days: int = 7) -> list:
        """Get weather forecast for next N days"""
        if pincode not in WeatherAPI.BANGALORE_ZONES:
            return []
        
        zone = WeatherAPI.BANGALORE_ZONES[pincode]
        
        try:
            response = requests.get(
                WeatherAPI.BASE_URL,
                params={
                    "latitude": zone["lat"],
                    "longitude": zone["lon"],
                    "daily": "weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum",
                    "temperature_unit": "celsius",
                    "timezone": "Asia/Kolkata",
                    "forecast_days": days
                }
            )
            
            if response.status_code == 200:
                data = response.json()
                daily = data['daily']
                
                forecasts = []
                for i in range(len(daily['time'])):
                    weather_code = daily['weather_code'][i]
                    temp_max = daily['temperature_2m_max'][i]
                    precip = daily['precipitation_sum'][i]
                    
                    forecasts.append({
                        'date': daily['time'][i],
                        'weather_code': weather_code,
                        'description': WeatherAPI.weather_code_to_description(weather_code),
                        'temp_max': temp_max,
                        'precipitation': precip,
                        'demand_multiplier': WeatherAPI.weather_to_demand_multiplier(weather_code, temp_max)
                    })
                
                return forecasts
        except Exception as e:
            print(f"⚠️ Weather API error: {e}")
            return []
    
    @staticmethod
    def weather_code_to_description(code: int) -> str:
        """Convert WMO weather code to human-readable description"""
        weather_codes = {
            0: "Clear sky",
            1: "Mainly clear",
            2: "Partly cloudy",
            3: "Overcast",
            45: "Foggy",
            48: "Foggy",
            51: "Light drizzle",
            53: "Moderate drizzle",
            55: "Dense drizzle",
            61: "Slight rain",
            63: "Moderate rain",
            65: "Heavy rain",
            71: "Slight snow",
            73: "Moderate snow",
            75: "Heavy snow",
            80: "Slight rain showers",
            81: "Moderate rain showers",
            82: "Violent rain showers",
            85: "Slight snow showers",
            86: "Heavy snow showers",
            95: "Thunderstorm",
            96: "Thunderstorm with hail",
            99: "Thunderstorm with hail"
        }
        return weather_codes.get(code, "Unknown")
    
    @staticmethod
    def weather_to_demand_multiplier(weather_code: int, temp: float) -> float:
        """Convert weather to demand multiplier for fashion"""
        
        # Base multiplier by weather condition
        if weather_code in [0, 1]:  # Clear/Mainly clear → sunny
            weather_mult = 1.0
        elif weather_code in [2, 3]:  # Cloudy
            weather_mult = 1.1
        elif weather_code in [45, 48]:  # Foggy
            weather_mult = 1.05
        elif weather_code in [51, 53, 55, 61, 63, 65, 80, 81, 82]:  # Rainy
            weather_mult = 1.4  # Rain increases demand for umbrellas, raincoats
        elif weather_code in [71, 73, 75, 85, 86]:  # Snowy
            weather_mult = 1.6  # Snow increases demand for warm clothing
        elif weather_code in [95, 96, 99]:  # Thunderstorm
            weather_mult = 1.5  # Storms increase demand for protective wear
        else:
            weather_mult = 1.0
        
        # Temperature effect
        if temp > 35:  # Heatwave (>35°C)
            temp_mult = 1.6  # High demand for light, breathable clothing
        elif temp > 30:  # Hot (30-35°C)
            temp_mult = 1.3
        elif 15 <= temp <= 30:  # Comfortable
            temp_mult = 1.0
        elif temp < 15:  # Cold (<15°C)
            temp_mult = 1.4  # Demand for sweaters, jackets
        else:
            temp_mult = 1.0
        
        # Combined effect (multiplicative)
        return weather_mult * temp_mult
    
    @staticmethod
    def display_current_weather_dashboard(pincodes: list = None):
        """Display current weather for all Bangalore zones"""
        if pincodes is None:
            pincodes = [560001, 560037, 560064]
        
        print("\n" + "="*80)
        print("🌤️  BANGALORE REAL-TIME WEATHER DASHBOARD")
        print("="*80)
        
        for pincode in pincodes:
            weather = WeatherAPI.get_current_weather(pincode)
            
            if weather:
                print(f"\n📍 {weather['zone']}")
                print(f"   Temperature: {weather['temperature']}°C")
                print(f"   Humidity: {weather['humidity']}%")
                print(f"   Wind: {weather['wind_speed']} km/h")
                print(f"   Condition: {weather['weather_description']}")
                print(f"   📊 Demand Multiplier: {weather['demand_multiplier']:.2f}x")
            else:
                print(f"\n⚠️  Could not fetch weather for pincode {pincode}")
        
        print("\n" + "="*80)
    
    @staticmethod
    def display_forecast_dashboard(pincode: int = 560001, days: int = 7):
        """Display weather forecast and demand implications"""
        print("\n" + "="*80)
        print(f"📈 7-DAY WEATHER FORECAST (Pincode {pincode})")
        print("="*80)
        
        forecast = WeatherAPI.get_forecast_weather(pincode, days)
        
        if forecast:
            for day in forecast:
                print(f"\n📅 {day['date']}")
                print(f"   {day['description']} | Max: {day['temp_max']}°C | Rain: {day['precipitation']}mm")
                print(f"   📊 Demand Impact: {day['demand_multiplier']:.2f}x")
        else:
            print("⚠️  Could not fetch forecast")
        
        print("\n" + "="*80)


if __name__ == "__main__":
    print("🌐 Testing Open-Meteo Weather API Integration\n")
    
    # Test 1: Current weather for all zones
    WeatherAPI.display_current_weather_dashboard()
    
    # Test 2: 7-day forecast
    WeatherAPI.display_forecast_dashboard(pincode=560001, days=7)
    
    # Test 3: Get raw data for integration
    print("\n" + "="*80)
    print("📋 RAW API RESPONSE (Current Weather - Pincode 560001)")
    print("="*80)
    current_weather = WeatherAPI.get_current_weather(560001)
    if current_weather:
        print(json.dumps(current_weather, indent=2))
    
    # Test 4: Weather to demand multiplier examples
    print("\n" + "="*80)
    print("🔢 WEATHER-TO-DEMAND MULTIPLIER EXAMPLES")
    print("="*80)
    
    scenarios = [
        (0, 35, "☀️ Clear, 35°C (Heatwave)"),
        (63, 28, "🌧️ Moderate Rain, 28°C"),
        (75, 5, "🌨️ Heavy Snow, 5°C"),
        (2, 20, "☁️ Cloudy, 20°C"),
        (95, 25, "⛈️ Thunderstorm, 25°C"),
    ]
    
    for code, temp, desc in scenarios:
        mult = WeatherAPI.weather_to_demand_multiplier(code, temp)
        print(f"{desc:<40} → Demand Multiplier: {mult:.2f}x")
    
    print("\n✅ Weather API integration test complete!")
