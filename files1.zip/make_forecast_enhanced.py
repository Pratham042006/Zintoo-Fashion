import pandas as pd
import numpy as np
from datetime import datetime, timedelta

# --- ENHANCED DEMAND FORECAST GENERATION ---

# Load your 7,000 synced products
df_products = pd.read_csv(r"D:\FASHION\data\products.csv")

# Generate synthetic demand data with HOURLY granularity + contextual signals
data = []
pincodes = [560001, 560037, 560064]  # Bangalore pincodes

print("Generating enhanced demand forecast with hourly granularity...")

for product_idx, (_, product) in enumerate(df_products.head(10).iterrows()):
    print(f"Processing product {product_idx + 1}/10: {product['productDisplayName']}")
    
    for pc in pincodes:
        # Base demand varies by product + pincode
        base_daily_demand = np.random.randint(10, 50)
        
        # Return rate (5-15% of customers return the item)
        return_rate = np.random.uniform(0.05, 0.15)
        
        # Generate for 30 days historical + 7 days forecast
        for day_offset in range(-30, 8):
            date = datetime.now() + timedelta(days=day_offset)
            date_str = date.strftime('%Y-%m-%d')
            is_forecast = day_offset > 0
            
            # Distribute daily demand across 24 hours
            # Peak hours: 6-9 AM (morning), 6-9 PM (evening)
            for hour in range(0, 24):
                # Hourly multiplier based on time of day
                if hour in [6, 7, 8]:  # Morning peak
                    hour_multiplier = 2.5
                elif hour in [18, 19, 20]:  # Evening peak
                    hour_multiplier = 2.2
                elif hour in [0, 1, 2, 3, 4, 5]:  # Night (low demand)
                    hour_multiplier = 0.3
                else:  # Regular hours
                    hour_multiplier = 1.0
                
                # Base hourly demand
                hourly_demand = (base_daily_demand / 24) * hour_multiplier
                
                # Add noise
                hourly_demand = max(0, hourly_demand + np.random.normal(0, 0.5))
                
                # Add trend for forecast period
                if is_forecast:
                    # Slightly increasing trend
                    trend_factor = 1.0 + (day_offset * 0.05)
                    hourly_demand *= trend_factor
                
                # Day-of-week effect
                day_of_week = (date.weekday() + 1) % 7
                if day_of_week in [5, 6]:  # Weekend (Sat, Sun)
                    dow_multiplier = 1.3
                else:
                    dow_multiplier = 1.0
                hourly_demand *= dow_multiplier
                
                # Return rate impact (reduces net demand)
                adjusted_demand = hourly_demand * (1 - return_rate)
                
                # Log entry
                data.append({
                    'product_id': int(product['id']),
                    'product_name': product['productDisplayName'],
                    'pincode': pc,
                    'date': date_str,
                    'hour': hour,
                    'demand': max(0, round(adjusted_demand, 2)),
                    'base_hourly_demand': max(0, round(hourly_demand, 2)),
                    'return_rate': round(return_rate, 3),
                    'day_of_week': day_of_week,
                    'is_forecast': is_forecast
                })

# Create DataFrame
df_forecast = pd.DataFrame(data)

# Save enhanced forecast
output_path = r"D:\FASHION\data\demand_forecast_enhanced.csv"
df_forecast.to_csv(output_path, index=False)

print(f"\n✅ Enhanced forecast generated!")
print(f"Total rows: {len(df_forecast)}")
print(f"Date range: {df_forecast['date'].min()} to {df_forecast['date'].max()}")
print(f"Hourly breakdown: 24 hours × 37 days × 10 products × 3 pincodes = {24 * 37 * 10 * 3} rows")
print(f"Saved to: {output_path}")

# --- SUMMARY STATISTICS ---
print("\n" + "="*70)
print("ENHANCED FORECAST SUMMARY")
print("="*70)

# Peak hours analysis
peak_hours = df_forecast[df_forecast['hour'].isin([6, 7, 8, 18, 19, 20])]
off_peak = df_forecast[~df_forecast['hour'].isin([6, 7, 8, 18, 19, 20])]

print(f"\nDemand by Time of Day:")
print(f"  Peak hours (6-9 AM, 6-9 PM): {peak_hours['demand'].mean():.2f} avg units/hour")
print(f"  Off-peak hours: {off_peak['demand'].mean():.2f} avg units/hour")
print(f"  Ratio: {peak_hours['demand'].mean() / off_peak['demand'].mean():.2f}x")

# Day of week analysis
weekend = df_forecast[df_forecast['day_of_week'].isin([5, 6])]
weekday = df_forecast[~df_forecast['day_of_week'].isin([5, 6])]

print(f"\nDemand by Day of Week:")
print(f"  Weekday: {weekday['demand'].mean():.2f} avg units/hour")
print(f"  Weekend: {weekend['demand'].mean():.2f} avg units/hour")
print(f"  Ratio: {weekend['demand'].mean() / weekday['demand'].mean():.2f}x")

# Return rate analysis
print(f"\nReturn Rate Impact:")
print(f"  Avg return rate: {df_forecast['return_rate'].iloc[0]:.1%}")
print(f"  Avg base demand (before returns): {df_forecast['base_hourly_demand'].mean():.2f}")
print(f"  Avg adjusted demand (after returns): {df_forecast['demand'].mean():.2f}")

# Forecast accuracy baseline
historical = df_forecast[df_forecast['is_forecast'] == False]
forecast = df_forecast[df_forecast['is_forecast'] == True]

print(f"\nHistorical vs Forecast:")
print(f"  Historical demand (30 days): {historical['demand'].mean():.2f} units/hour")
print(f"  Forecasted demand (7 days): {forecast['demand'].mean():.2f} units/hour")
print(f"  Trend: {((forecast['demand'].mean() / historical['demand'].mean()) - 1) * 100:+.1f}%")

# Pincode analysis
print(f"\nDemand by Pincode:")
for pc in pincodes:
    pc_data = df_forecast[df_forecast['pincode'] == pc]
    print(f"  {pc}: {pc_data['demand'].mean():.2f} avg units/hour | "
          f"Peak: {pc_data['demand'].max():.2f} | Min: {pc_data['demand'].min():.2f}")

print("\n" + "="*70)
print("Sample rows from enhanced forecast:")
print("="*70)
print(df_forecast[['product_name', 'pincode', 'date', 'hour', 'demand', 'return_rate', 'is_forecast']].head(50))
